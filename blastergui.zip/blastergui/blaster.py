from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.gridlayout import GridLayout
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout

class Register(GridLayout):
    def __init__(self, **kwargs):
        super(Register, self).__init__(cols=1, spacing=10, padding=150, **kwargs)
        self.add_widget(Label(text="[b]INFIMAILER[/b]", markup=True, font_size=30))
        self.username = TextInput(multiline=False)
        self.password = TextInput(multiline=False, password=True)
        self.add_widget(Label(text="Username"))
        self.add_widget(self.username)
        self.add_widget(Label(text="Password"))
        self.add_widget(self.password)
        self.login_button = Button(text='Login')
        self.add_widget(self.login_button)
        self.login_button.bind(on_press=self.displayPopup)

    def displayPopup(self, btn):
        if self.username.text == 'whitebee' and self.password.text == '123':
            myPopUp = Popup(title='Registration Status', content=Label(text='Login Successful'), size_hint=(.5, .5))
            myPopUp.open()
            myPopUp.bind(on_dismiss=self.change_screen)
        else:
            myPopUp = Popup(title='Registration Status', content=Label(text='Login Attempt Failed'), size_hint=(.5, .5))
            myPopUp.open()

    def change_screen(self, instance):
        self.parent.parent.current = 'main'

class MainScreen(BoxLayout):
    def __init__(self, **kwargs):
        super(MainScreen, self).__init__(orientation='vertical', **kwargs)

        grid_layout = GridLayout(cols=2, spacing=10)
        grid_layout.add_widget(Label(text="Date"))
        self.date_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.date_input)

        grid_layout.add_widget(Label(text="Number"))
        self.number_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.number_input)

        grid_layout.add_widget(Label(text="SUBJECT"))
        self.subject_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.subject_input)

        grid_layout.add_widget(Label(text="Product"))
        self.product_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.product_input)

        grid_layout.add_widget(Label(text="Quantity"))
        self.quantity_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.quantity_input)

        grid_layout.add_widget(Label(text="Name"))
        self.name_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.name_input)

        grid_layout.add_widget(Label(text="EMAIL"))
        self.name_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.name_input)


        grid_layout.add_widget(Label(text="PASSWORD"))
        self.name_input = TextInput(multiline=False, size_hint_y=None, height=30)
        grid_layout.add_widget(self.name_input)

        grid_layout.add_widget(Label(text="BODY"))
        self.body_input = TextInput(multiline=True, size_hint_y=None, height=100)
        grid_layout.add_widget(self.body_input)

        self.imp_button = Button(text="IMPORT DATA", size_hint_y=None, height=30)
        grid_layout.add_widget(self.imp_button)
        self.import_data_input = TextInput(multiline=True, size_hint_y=None, height=100)
        grid_layout.add_widget(self.import_data_input)

        grid_layout.add_widget(Label(text="CONTENT"))
        self.content_input = TextInput(multiline=True, size_hint_y=None, height=100)
        grid_layout.add_widget(self.content_input)

        self.start_button = Button(text="START", size_hint_y=None, height=30)
        grid_layout.add_widget(self.start_button)

        self.stop_button = Button(text="STOP", size_hint_y=None, height=30)
        grid_layout.add_widget(self.stop_button)

        self.add_widget(grid_layout)

class RegistrationApp(App):
    def build(self):
        self.screen_manager = ScreenManager()
        self.register_screen = Screen(name='register')
        self.main_screen = Screen(name='main')
        self.register_screen.add_widget(Register())
        self.main_screen.add_widget(MainScreen())
        self.screen_manager.add_widget(self.register_screen)
        self.screen_manager.add_widget(self.main_screen)
        return self.screen_manager

if __name__ == "__main__":
    RegistrationApp().run()